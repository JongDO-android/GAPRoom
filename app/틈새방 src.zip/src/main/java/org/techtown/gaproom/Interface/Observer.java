package org.techtown.gaproom.Interface;

public interface Observer {
    void update(String address);
}
